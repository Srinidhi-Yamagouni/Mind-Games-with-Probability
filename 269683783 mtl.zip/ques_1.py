"""
Use the following functions to add, multiply and divide, taking care of the modulo operation.
Use mod_add to add two numbers taking modulo 1000000007. ex : c=a+b --> c=mod_add(a,b)
Use mod_multiply to multiply two numbers taking modulo 1000000007. ex : c=a*b --> c=mod_multiply(a,b)
Use mod_divide to divide two numbers taking modulo 1000000007. ex : c=a/b --> c=mod_divide(a,b)
"""
M=1000000007

def mod_add(a, b):
    a=(a%M+M)%M
    b=(b%M+M)%M
    return (a+b)%M

def mod_multiply(a, b):
    a=(a%M+M)%M
    b=(b%M+M)%M
    return (a*b)%M

def mod_divide(a, b):
    a=(a%M+M)%M
    b=(b%M+M)%M
    return mod_multiply(a, pow(b, M-2, M))

# Problem 1a
arr = []
for i in range(100):
    arr.append([])
    for j in range(100):
        arr[i].append(0)

def calc_prob(a, b):
    """
    Returns:
        The probability of Alice winning alice_wins times and Bob winning bob_wins times will be of the form p/q,
        where p and q are positive integers,
        return p.q^(-1) mod 1000000007.
    """
    if arr[a][b] !=0:
        return arr[a][b]
    else:
        if a==1 and b==1:
            res =  1
        elif a == 1:
            res = mod_divide(mod_multiply(a, calc_prob(a, b-1)), mod_add(mod_add(a,b),-1))
        elif b == 1:
            res = mod_divide(mod_multiply(b, calc_prob(a-1, b)), mod_add(mod_add(a,b),-1))
        else:
            res = mod_add(mod_divide(mod_multiply(b, calc_prob(a-1, b)), mod_add(mod_add(a,b),-1)),mod_divide(mod_multiply(a, calc_prob(a, b-1)),  mod_add(mod_add(a,b),-1)) )
        arr[a][b] = res
        return res
        
# Problem 1b (Expectation)      
def calc_expectation(t):
    res = 0
    for i in range (-1*(t-2), t-1, 2):
        res=mod_add(res, mod_multiply(i,calc_prob(mod_divide(mod_add(t,i),2),mod_divide(mod_add(t,mod_multiply(-1,i)),2))))
    return res

# Problem 1b (Variance)
def calc_variance(t):
    res=0
    for i in range ((-1 *(t-2)), t-1, 2):
        res=mod_add(res, mod_multiply(i*i,calc_prob(mod_divide(mod_add(t,i),2),mod_divide(mod_add(t,mod_multiply(-1,i)),2)) ))
    return res - calc_expectation(t)

print(calc_prob(99, 93))