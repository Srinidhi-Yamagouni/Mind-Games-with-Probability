import numpy as np

class Alice:
    def __init__(self):
        self.past_play_styles = [1, 1]
        self.results = [1, 0]
        self.opp_play_styles = [1, 1]
        self.points = 1
        self.opp_points = 1
        self.defence = 0
        self.attack = 0

    def play_move(self):
        """
        Decide Alice's play style for the current round.
        Returns: 
            0 : attack
            1 : balanced
            2 : defence
        """
        pt = (self.opp_points / (self.points + self.opp_points))
        if pt > 15 / 44:
            self.attack += 1
            return 0  # Attack
        else:
            self.defence += 1
            return 2  # Defence

    def observe_result(self, own_style, opp_style, result):
        """
        Update Alice's knowledge after each round based on the observed results.
        """
        self.past_play_styles.append(own_style)
        self.results.append(result)
        self.opp_play_styles.append(opp_style)
        self.points += result
        self.opp_points += (1 - result)


class Bob:
    def __init__(self):
        self.past_play_styles = [1, 1]
        self.results = [0, 1]
        self.opp_play_styles = [1, 1]
        self.points = 1

    def play_move(self):
        """
        Bob randomly chooses his move.
        Returns: 
            0 : attack
            1 : balanced
            2 : defence
        """
        return np.random.choice([0, 1, 2])

    def observe_result(self, own_style, opp_style, result):
        """
        Update Bob's knowledge after each round based on the observed results.
        """
        self.past_play_styles.append(own_style)
        self.results.append(result)
        self.opp_play_styles.append(opp_style)
        self.points += result


def optimal_strategy(na, nb, tot_rounds):
    """
    Run the game for tot_rounds rounds and update the matrix dynamically based on points.
    """
    return [1, 0, 0]

def simulate_round(alice, bob, payoff_matrix):
    """
    Simulates a single round of the game between Alice and Bob.
    
    Returns:
        None
    """
    bob_move=bob.play_move()
    alice_move= 0
    alice_win, tie, bob_win = payoff_matrix[alice_move][bob_move]
    res=np.random.choice([1,0.5,0], p = [alice_win, tie, bob_win])
    alice.observe_result(alice_move, bob_move, res)
    bob.observe_result(bob_move, alice_move, 1-res)

def expected_points(tot_rounds):
    """
    Calculate the expected points that Alice can score after tot_rounds rounds.
    """
    ans = 0
    for _ in range(10**4):
        alice=Alice()
        bob=Bob()
        mtrx=[
                [(1/2,0,1/2), (7/10,0,3/10), (5/11,0,6/11)],
                [(3/10,0,7/10), (1/3, 1/3, 1/3), (3/10,1/2,1/5)],
                [(6/11,0,5/11), (1/5,1/2,3/10), (1/10,4/5,1/10)]
            ]
        for i in range(tot_rounds-2):
            simulate_round(alice, bob , mtrx)
            pa=alice.points
            pb=bob.points
            mtrx[0][0]=((pb)/(pa+pb), 0, (pa)/(pa+pb))
        ans+= alice.points
    return ans/10000

print(expected_points(4))